export const GAME_VERSION = 'v2.5';
export const LOADER_TEXT = `Loading ${GAME_VERSION}...`;    