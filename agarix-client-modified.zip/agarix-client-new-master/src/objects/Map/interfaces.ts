export default interface IMapObject {
  renderTick: () => void
}