export default new class SettingsState {
  fullMapViewRender: boolean = true;
  rings: boolean = true;
  showMassMyCell: boolean = true;
  showNickMyCell: boolean = true;
  allowSkins: boolean = true;
}