type ChatAuthor = {
  Game: '[Game]',
  TabsController: '[TabsController]';
  QuickRespawn: '[QuickRespawn]';
  Spectator: '[Spectator]';
  Facebook: '[Facebook]',
  Google: '[Google]',
}

export const ChatAuthor: ChatAuthor = {
  Game: '[Game]',
  TabsController: '[TabsController]',
  QuickRespawn: '[QuickRespawn]',
  Spectator: '[Spectator]',
  Facebook: '[Facebook]',
  Google: '[Google]'
}